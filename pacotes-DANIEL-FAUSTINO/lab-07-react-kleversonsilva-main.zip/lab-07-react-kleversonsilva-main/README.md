[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/t_5Sx5Pk)
# ReactJS Tempalte
## Getting Started


This is a project template used o P6-SI-PASI class.

This react template is managed by [vite](https://vitejs.dev/)

### Install dependencies
``` npm install```
### Run app on dev mode
``` npm run dev```
### Build app
``` npm run build```