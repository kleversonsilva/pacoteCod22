// var p = fetch('https://swapi.tech/api/planetas/?page=2')
//     .then(response => response.json())
//     .then(json => {
//         //console.log(json.results);
//         console.log(json);

//         var planets = json.results;

//         planets.filter(planet => {
//             if (planet.name === "frozen") {
//                 console.log(planet);
//             }
//         });

//         // planets.forEach(planet => {
//         //     console.log(planet.name);
//         // })
       
//     })
//     .catch(err => console.error(err))

//console.log(p);

var p = fetch('https://swapi.online/api/planets/?page=2')

  .then(response => response.json())
  .then(json => {
    //console.log(json);
    const planetas = json.results;
    
    const frozenplanetas = planetas.filter(planet => planet.climate.includes('frozen'));
    console.log("Planetas com clima 'frozen':", frozenplanetas);
    
    const temperateplanetas = planetas.map(planet => planet.climate.includes('temperate'));
    console.log("Planetas com clima 'temperate':", temperateplanetas);
    
    
    const countTemperateplanetas = temperateplanetas.reduce((count, isTemperate) => {
      return count + (isTemperate ? 1 : 0);
    }, 0);
    console.log("Número de planetas com clima 'temperate':", countTemperateplanetas);
  })

  .catch(error => {
    console.error('There was a problem with the fetch operation:', error);
  });


  async function fetchStarWarsCharacters() {
    try {
      const response = await fetch('https://swapi.online/api/people/?page=2');
    
      const data = await response.json();
      const characters = data.results;
  
      const greenSkinCharacters = characters.filter(character => character.skin_color.toLowerCase().includes('green'));
      console.log("Personagens com cor de pele verde:", greenSkinCharacters);

      const characterWithMassGreaterThan100 = characters.find(character => parseFloat(character.mass) > 100);
      console.log("Personagem com massa maior que 100:", characterWithMassGreaterThan100);
  
      const countTallCharacters = characters.reduce((count, character) => {
        return count + (parseFloat(character.height) >= 177 ? 1 : 0);
      }, 0);
      console.log("Número de personagens com altura maior ou igual a 177:", countTallCharacters);
  
      const characterNames = characters.map(character => character.name);
      console.log("Nomes de todos os personagens:", characterNames);

    } catch (error) {
      console.error('There was a problem with the fetch operation:', error);
    }
  }
  
  fetchStarWarsCharacters();
