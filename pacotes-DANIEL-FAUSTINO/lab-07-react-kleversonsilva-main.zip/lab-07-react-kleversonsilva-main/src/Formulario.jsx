import { CaixaDeTexto } from "./CaixaDeTexto";
import { Botao } from "./Botao";
import { Senha } from "./Senha";

export function Formulario() {
    return (
        <form>
            <div>
                <label>Nome: </label>
                // input
                <CaixaDeTexto placeholder="Digite seu nome" />
            </div>
            <div>
                <label >Sobrenome: </label>
                <CaixaDeTexto placeholder="Digite seu sobrenome" />
            </div>
            <div>
                <label>Email: </label>
                <CaixaDeTexto placeholder="Digite seu email" />
            </div>
            <div>
                <label>Senha: </label>
                <Senha />
            </div>
            <Botao texto="Enviar" onClick={handleSubmit} />
            <Botao texto="Enviar" onClick={handleCancelar} />

        </form>
    );
};