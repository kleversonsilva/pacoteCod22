export function Botao(texto, onClick) {
    return (
        <button className="botao" onClick={onClick}>
            {texto}
        </button>
    )
}