window.addEventListener('load', function() {
    const estadoSelect = document.getElementById('estadoSelect');
    const cidadeTitle = document.getElementById('cidadeTitle');
    const cidadeSelect = document.getElementById('cidadeSelect');
    const verMaisBtn = document.getElementById('verMaisBtn');
  
    // Carregar lista de estados
    fetch('https://servicodados.ibge.gov.br/api/v1/localidades/estados')
      .then(response => response.json())
      .then(data => {
        data.forEach(estado => {
          const option = document.createElement('option');
          option.value = estado.sigla;
          option.textContent = estado.nome;
          estadoSelect.appendChild(option);
        });
      });
  
    // Evento de seleção de estado
    estadoSelect.addEventListener('change', function() {
      const estadoSelecionado = estadoSelect.value;
      if (estadoSelecionado) {
        // Carregar lista de cidades
        fetch(`https://servicodados.ibge.gov.br/api/v1/localidades/estados/${estadoSelecionado}/municipios`)
          .then(response => response.json())
          .then(data => {
            cidadeSelect.innerHTML = '<option value="">Selecione uma cidade</option>';
            data.forEach(cidade => {
              const option = document.createElement('option');
              option.value = cidade.nome;
              option.textContent = cidade.nome;
              cidadeSelect.appendChild(option);
            });
            cidadeTitle.style.display = 'block';
            cidadeSelect.style.display = 'block';
            verMaisBtn.style.display = 'block';
          });
      } else {
        cidadeTitle.style.display = 'none';
        cidadeSelect.style.display = 'none';
        verMaisBtn.style.display = 'none';
      }
    });
  
    // Evento de clique no botão "Ver mais"
    verMaisBtn.addEventListener('click', function() {
      const estadoSelecionado = estadoSelect.value;
      const cidadeSelecionada = cidadeSelect.value;
      if (estadoSelecionado && cidadeSelecionada) {
        fetch(`https://servicodados.ibge.gov.br/api/v1/localidades/estados/${estadoSelecionado}/municipios/${cidadeSelecionada}`)
          .then(response => response.json())
          .then(data => {
            alert(`Microrregião: ${data.microrregiao.nome}\nMesorregião: ${data.mesorregiao.nome}\nRegião: ${data.mesorregiao.UF.regiao.nome}`);
          });
      } else {
        alert('Por favor, selecione um estado e uma cidade antes de ver mais informações.');
      }
    });
  });