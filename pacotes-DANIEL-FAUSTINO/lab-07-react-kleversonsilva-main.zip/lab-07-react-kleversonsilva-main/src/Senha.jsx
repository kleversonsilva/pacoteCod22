const { useState } = require("react");

export function Senha() {
    const [senha, setSenha] = useState("");
    const [senhaConfirmacao, setSenhaConfirmacao] = useState("");

    function validarSenha() {
        if (senha === senhaConfirmacao) {
            alert("Senhas iguais");
        } else {
            alert("Senhas diferentes");
        }
    }

    return (
        <div>
            <input
                className="caixa-texto"
                type="password"
                placeholder="Senha"
                value={senha}
                onChange={(evento) => setSenha(evento.target.value)}
            />
            <input
                className="caixa-texto"
                type="password"
                placeholder="Confirmação da senha"
                value={senhaConfirmacao}
                onChange={(evento) => setSenhaConfirmacao(evento.target.value)}
            />
            <button className="botao" onClick={validarSenha}>
                Validar
            </button>
        </div>
    );

}