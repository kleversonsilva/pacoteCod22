export function CaixaDeTexto(placeholder) {
    return (
        <input
            className="caixa-texto"
            type="text"
            placeholder={placeholder}
        />
    )
}